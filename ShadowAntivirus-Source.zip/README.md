# Shadow Antivirus

Shadow Antivirus is a local Windows process monitor with basic heuristic risk flags. It is not a full antivirus product and does not replace Microsoft Defender.

## Project layout

- `src\UI\` contains the WPF application and setup windows.
- `src\Monitoring\` contains process rows and risk assessment.
- `src\Installation\` contains install, startup, and uninstall logic.
- `publish\ShadowAntivirus.exe` is the self-contained standalone executable.
- `publish\upload\ShadowAntivirus.exe` is a much smaller build for upload; it requires the .NET 8 Windows Desktop Runtime on the target PC.
- `publish\upload\ShadowAntivirus-Source.zip` contains the source code and project files without generated build output.
- `bin\` and `obj\` are generated build folders and are excluded from Git.

Build from the project root with `dotnet build .\ShadowAntivirus.csproj -c Release`. To refresh the standalone executable, run:

```powershell
dotnet publish .\ShadowAntivirus.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
```

For a smaller, framework-dependent executable (requires the .NET 8 Windows Desktop Runtime on the target PC), publish to a separate folder:

```powershell
dotnet publish .\ShadowAntivirus.csproj -c Release -r win-x64 --self-contained false -p:PublishSingleFile=true -o .\publish\upload
```

## Install

Run `publish\ShadowAntivirus.exe` for a self-contained install, or `publish\upload\ShadowAntivirus.exe` if .NET 8 Windows Desktop Runtime is installed. On first launch, choose an install folder and select **Install**. The default is `%LOCALAPPDATA%\Programs\Shadow Antivirus`. Setup copies the executable into that folder, adds a shortcut to the current Windows user's Startup folder, and creates an **Uninstall Shadow Antivirus** shortcut in the Start menu.

The app and startup entry are installed for the current Windows user and do not require administrator access. Startup occurs when that user signs in, not before Windows sign-in.

## Uninstall

Select **Uninstall** in the app, or open Start and run **Uninstall Shadow Antivirus**. Confirm the prompt. The uninstaller removes Shadow Antivirus's startup shortcut, Start menu uninstaller entry, saved rules, registry entries, and executable. Other files in the selected install folder are left untouched.

## Automatic risk checks

The monitor flags a Windows system-process name running outside the Windows system folders and executables launched from temporary, Downloads, or Startup folders. These are indicators for review, not proof of malware. It does not automatically stop flagged processes. Keep Microsoft Defender enabled.

## Backgrounds

Use **Change background…** to select a JPG/PNG image or an MP4/WMV video. Videos are muted and loop while the app is open. The chosen file path is saved locally; keep the file in place. **Default background** clears the selection.

## Process controls

Allow and deny rules are local to Shadow Antivirus. Deny stops a matching process while the monitor is running; it is not a guaranteed Windows launch block.

## License

Shadow Antivirus is open source under the MIT License. See [LICENSE](LICENSE).
