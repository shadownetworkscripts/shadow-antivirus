using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;
using System.Windows;

namespace ProcessSentinel;

internal static class InstallationManager
{
    private const string InstallRegistryPath = @"Software\ShadowAntivirus";
    private const string UninstallRegistryPath =
        @"Software\Microsoft\Windows\CurrentVersion\Uninstall\ShadowAntivirus";
    private const string LegacyInstallRegistryPath = @"Software\ProcessSentinel";
    private const string LegacyUninstallRegistryPath =
        @"Software\Microsoft\Windows\CurrentVersion\Uninstall\ProcessSentinel";
    private const string ExecutableName = "ShadowAntivirus.exe";
    private const string StartupShortcutName = "Shadow Antivirus.lnk";
    private const string UninstallShortcutName = "Uninstall Shadow Antivirus.lnk";
    private const string AppStartMenuFolder = "Shadow Antivirus";
    private const string LegacyStartupShortcutName = "Process Sentinel.lnk";
    private const string LegacyUninstallShortcutName = "Uninstall Process Sentinel.lnk";
    private const string LegacyAppStartMenuFolder = "Process Sentinel";

    public static bool IsInstalledExecutable(string executablePath)
    {
        var registeredPath = GetRegisteredExecutable();
        return !string.IsNullOrWhiteSpace(registeredPath)
            && PathsEqual(executablePath, registeredPath);
    }

    public static string GetSuggestedInstallDirectory()
    {
        return Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "Programs",
            "Shadow Antivirus");
    }

    public static string? Install(string sourceExecutable, string selectedDirectory)
    {
        var installDirectory = Path.GetFullPath(selectedDirectory);
        var installedExecutable = Path.Combine(installDirectory, ExecutableName);
        var sameExecutable = PathsEqual(sourceExecutable, installedExecutable);
        var registeredPath = GetRegisteredExecutable();
        var hasExistingRegistration = !string.IsNullOrWhiteSpace(registeredPath)
            && File.Exists(registeredPath);
        var updatingSamePath = hasExistingRegistration
            && PathsEqual(registeredPath!, installedExecutable);

        if (!sameExecutable && File.Exists(installedExecutable) && !updatingSamePath)
        {
            MessageBox.Show(
                $"A file already exists here and will not be overwritten:\n\n{installedExecutable}\n\nChoose another folder.",
                "Shadow Antivirus",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return null;
        }

        if (hasExistingRegistration && !sameExecutable)
        {
            var action = updatingSamePath ? "replace" : "move";
            var answer = MessageBox.Show(
                $"Shadow Antivirus is currently installed here:\n\n{registeredPath}\n\nDo you want to {action} the installation to:\n\n{installedExecutable}\n\nThe running app will close during setup.",
                "Set up Shadow Antivirus",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (answer != MessageBoxResult.Yes)
            {
                return null;
            }

            CloseRunningInstalledCopy(registeredPath!);
        }

        var copiedExecutable = false;
        var registrationCommitted = false;
        try
        {
            Directory.CreateDirectory(installDirectory);
            if (!sameExecutable)
            {
                copiedExecutable = !File.Exists(installedExecutable);
                File.Copy(sourceExecutable, installedExecutable, overwrite: updatingSamePath);
            }

            var startMenuFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Programs),
                AppStartMenuFolder);
            Directory.CreateDirectory(startMenuFolder);
            CreateShortcut(
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), StartupShortcutName),
                installedExecutable,
                installDirectory,
                string.Empty);
            CreateShortcut(
                Path.Combine(startMenuFolder, UninstallShortcutName),
                installedExecutable,
                installDirectory,
                "--uninstall");

            RegisterInstall(installedExecutable, installDirectory);
            registrationCommitted = true;
            RemoveLegacyShortcuts();
            RemoveLegacyRegistration();
            if (hasExistingRegistration && !PathsEqual(registeredPath!, installedExecutable))
            {
                ScheduleExecutableDeletion(registeredPath!);
            }

            return installedExecutable;
        }
        catch (Exception ex) when (ex is IOException
                                   or UnauthorizedAccessException
                                   or SecurityException
                                   or InvalidOperationException
                                   or COMException)
        {
            if (!registrationCommitted)
            {
                RemoveShortcuts();
                RemoveCurrentRegistration();
                if (copiedExecutable)
                {
                    File.Delete(installedExecutable);
                }
            }

            throw;
        }
    }

    public static void Uninstall(string currentExecutable)
    {
        var registeredPath = GetRegisteredExecutable();
        if (registeredPath is null || !PathsEqual(registeredPath, currentExecutable))
        {
            MessageBox.Show(
                "Shadow Antivirus is not installed from this location.",
                "Uninstall Shadow Antivirus",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            return;
        }

        var answer = MessageBox.Show(
            "Uninstall Shadow Antivirus?\n\nThis removes its startup shortcut, uninstaller entry, saved rules, registry entries, and executable. Other files in the installation folder will be left untouched.",
            "Uninstall Shadow Antivirus",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (answer != MessageBoxResult.Yes)
        {
            return;
        }

        RemoveShortcuts();
        RemoveLegacyShortcuts();
        RemoveRegistration();
        RemoveSavedRules();
        ScheduleExecutableDeletion(registeredPath);

        MessageBox.Show(
            "Shadow Antivirus has been uninstalled. The executable will be removed after this window closes.",
            "Uninstall Shadow Antivirus",
            MessageBoxButton.OK,
            MessageBoxImage.Information);
    }

    private static void RegisterInstall(string executablePath, string installDirectory)
    {
        using (var installKey = Registry.CurrentUser.CreateSubKey(InstallRegistryPath))
        {
            installKey.SetValue("InstallPath", executablePath, RegistryValueKind.String);
        }

        using var uninstallKey = Registry.CurrentUser.CreateSubKey(UninstallRegistryPath);
        var command = $"\"{executablePath}\" --uninstall";
        uninstallKey.SetValue("DisplayName", "Shadow Antivirus", RegistryValueKind.String);
        uninstallKey.SetValue("DisplayVersion", "1.0.0", RegistryValueKind.String);
        uninstallKey.SetValue("Publisher", "Shadow Antivirus", RegistryValueKind.String);
        uninstallKey.SetValue("InstallLocation", installDirectory, RegistryValueKind.String);
        uninstallKey.SetValue("DisplayIcon", executablePath, RegistryValueKind.String);
        uninstallKey.SetValue("UninstallString", command, RegistryValueKind.String);
        uninstallKey.SetValue("QuietUninstallString", command, RegistryValueKind.String);
        uninstallKey.SetValue("NoModify", 1, RegistryValueKind.DWord);
        uninstallKey.SetValue("NoRepair", 1, RegistryValueKind.DWord);
    }

    private static void CreateShortcut(
        string shortcutPath,
        string targetPath,
        string workingDirectory,
        string arguments)
    {
        var shellType = Type.GetTypeFromProgID("WScript.Shell")
            ?? throw new PlatformNotSupportedException("Windows Script Host is unavailable.");
        object? shell = null;
        object? shortcut = null;
        try
        {
            shell = Activator.CreateInstance(shellType)
                ?? throw new InvalidOperationException("Could not create the Windows shortcut service.");
            shortcut = shellType.InvokeMember(
                "CreateShortcut",
                BindingFlags.InvokeMethod,
                null,
                shell,
                [shortcutPath]);
            if (shortcut is null)
            {
                throw new InvalidOperationException("Windows did not create the shortcut.");
            }

            SetComProperty(shortcut, "TargetPath", targetPath);
            SetComProperty(shortcut, "WorkingDirectory", workingDirectory);
            SetComProperty(shortcut, "Arguments", arguments);
            SetComProperty(shortcut, "Description", "Shadow Antivirus");
            shortcut.GetType().InvokeMember("Save", BindingFlags.InvokeMethod, null, shortcut, null);
        }
        finally
        {
            if (shortcut is not null && Marshal.IsComObject(shortcut))
            {
                Marshal.FinalReleaseComObject(shortcut);
            }

            if (shell is not null && Marshal.IsComObject(shell))
            {
                Marshal.FinalReleaseComObject(shell);
            }
        }
    }

    private static void SetComProperty(object? target, string name, string value)
    {
        if (target is null)
        {
            throw new InvalidOperationException("Windows did not create the shortcut.");
        }

        target.GetType().InvokeMember(
            name,
            BindingFlags.SetProperty,
            null,
            target,
            [value]);
    }

    private static string? GetRegisteredExecutable()
    {
        using var key = Registry.CurrentUser.OpenSubKey(InstallRegistryPath);
        var currentPath = key?.GetValue("InstallPath") as string;
        if (!string.IsNullOrWhiteSpace(currentPath))
        {
            return currentPath;
        }

        using var legacyKey = Registry.CurrentUser.OpenSubKey(LegacyInstallRegistryPath);
        var legacyPath = legacyKey?.GetValue("InstallPath") as string;
        using var legacyUninstallKey = Registry.CurrentUser.OpenSubKey(LegacyUninstallRegistryPath);
        return legacyUninstallKey?.GetValue("DisplayName") as string == "Process Sentinel"
            ? legacyPath
            : null;
    }

    private static void CloseRunningInstalledCopy(string executablePath)
    {
        var processName = Path.GetFileNameWithoutExtension(executablePath);
        foreach (var process in Process.GetProcessesByName(processName))
        {
            using (process)
            {
                string? runningPath;
                try
                {
                    runningPath = process.MainModule?.FileName;
                }
                catch (Win32Exception ex)
                {
                    throw new InvalidOperationException(
                        $"Could not verify the running app before updating it: {ex.Message}",
                        ex);
                }

                if (string.IsNullOrWhiteSpace(runningPath) || !PathsEqual(runningPath, executablePath))
                {
                    continue;
                }

                if (!process.CloseMainWindow() && !process.HasExited)
                {
                    process.Kill(entireProcessTree: false);
                }

                if (!process.WaitForExit(TimeSpan.FromSeconds(15)))
                {
                    throw new InvalidOperationException(
                        "The installed app did not close in time. Close it and run setup again.");
                }
            }
        }
    }

    private static void RemoveRegistration()
    {
        RemoveCurrentRegistration();
        RemoveLegacyRegistration();
    }

    private static void RemoveCurrentRegistration()
    {
        Registry.CurrentUser.DeleteSubKeyTree(InstallRegistryPath, throwOnMissingSubKey: false);
        Registry.CurrentUser.DeleteSubKeyTree(UninstallRegistryPath, throwOnMissingSubKey: false);
    }

    private static void RemoveLegacyRegistration()
    {
        bool isLegacyInstall;
        using (var legacyUninstall = Registry.CurrentUser.OpenSubKey(LegacyUninstallRegistryPath))
        {
            isLegacyInstall = legacyUninstall?.GetValue("DisplayName") as string == "Process Sentinel";
        }

        if (isLegacyInstall)
        {
            Registry.CurrentUser.DeleteSubKeyTree(LegacyInstallRegistryPath, throwOnMissingSubKey: false);
            Registry.CurrentUser.DeleteSubKeyTree(LegacyUninstallRegistryPath, throwOnMissingSubKey: false);
        }
    }

    private static void RemoveShortcuts()
    {
        var startupShortcut = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Startup),
            StartupShortcutName);
        var uninstallShortcut = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Programs),
            AppStartMenuFolder,
            UninstallShortcutName);
        File.Delete(startupShortcut);
        File.Delete(uninstallShortcut);

        var startMenuFolder = Path.GetDirectoryName(uninstallShortcut)!;
        if (Directory.Exists(startMenuFolder) && !Directory.EnumerateFileSystemEntries(startMenuFolder).Any())
        {
            Directory.Delete(startMenuFolder);
        }
    }

    private static void RemoveLegacyShortcuts()
    {
        var legacyStartupShortcut = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Startup),
            LegacyStartupShortcutName);
        var legacyUninstallShortcut = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.Programs),
            LegacyAppStartMenuFolder,
            LegacyUninstallShortcutName);
        File.Delete(legacyStartupShortcut);
        File.Delete(legacyUninstallShortcut);

        var legacyFolder = Path.GetDirectoryName(legacyUninstallShortcut)!;
        if (Directory.Exists(legacyFolder) && !Directory.EnumerateFileSystemEntries(legacyFolder).Any())
        {
            Directory.Delete(legacyFolder);
        }
    }

    private static void RemoveSavedRules()
    {
        var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        foreach (var name in new[] { "ShadowAntivirus", "ProcessSentinel" })
        {
            var settingsDirectory = Path.Combine(localAppData, name);
            File.Delete(Path.Combine(settingsDirectory, "rules.json"));
            File.Delete(Path.Combine(settingsDirectory, "settings.json"));
            if (Directory.Exists(settingsDirectory)
                && !Directory.EnumerateFileSystemEntries(settingsDirectory).Any())
            {
                Directory.Delete(settingsDirectory);
            }
        }
    }

    private static void ScheduleExecutableDeletion(string executablePath)
    {
        var directory = Path.GetDirectoryName(executablePath)!;
        var command =
            $"/d /c ping 127.0.0.1 -n 3 > nul & del /f /q \"{executablePath}\" & rmdir \"{directory}\"";
        var cleanup = Process.Start(new ProcessStartInfo
        {
            FileName = Environment.GetEnvironmentVariable("ComSpec") ?? "cmd.exe",
            Arguments = command,
            UseShellExecute = false,
            CreateNoWindow = true
        });
        if (cleanup is null)
        {
            throw new InvalidOperationException("Could not schedule removal of the installed executable.");
        }
    }

    private static bool PathsEqual(string left, string right) =>
        string.Equals(
            Path.GetFullPath(left).TrimEnd(Path.DirectorySeparatorChar),
            Path.GetFullPath(right).TrimEnd(Path.DirectorySeparatorChar),
            StringComparison.OrdinalIgnoreCase);
}
