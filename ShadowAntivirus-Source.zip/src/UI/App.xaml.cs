using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Windows;

namespace ProcessSentinel;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        var executablePath = Environment.ProcessPath;
        if (string.IsNullOrWhiteSpace(executablePath))
        {
            ShowStartupError("Could not determine the running executable location.");
            Shutdown();
            return;
        }

        try
        {
            if (e.Args.Contains("--uninstall", StringComparer.OrdinalIgnoreCase))
            {
                InstallationManager.Uninstall(executablePath);
                Shutdown();
                return;
            }

            if (!InstallationManager.IsInstalledExecutable(executablePath))
            {
                var setupWindow = new InstallWindow();
                MainWindow = setupWindow;
                if (setupWindow.ShowDialog() != true)
                {
                    Shutdown();
                    return;
                }

                var installedPath = InstallationManager.Install(
                    executablePath,
                    setupWindow.InstallDirectory);
                if (installedPath is null)
                {
                    Shutdown();
                    return;
                }

                if (!string.Equals(
                    Path.GetFullPath(executablePath),
                    Path.GetFullPath(installedPath),
                    StringComparison.OrdinalIgnoreCase))
                {
                    Process.Start(new ProcessStartInfo(installedPath)
                    {
                        UseShellExecute = true
                    });
                    Shutdown();
                    return;
                }
            }

            var window = new MainWindow();
            MainWindow = window;
            window.Show();
        }
        catch (IOException ex)
        {
            ShowStartupError(ex.Message);
            Shutdown();
        }
        catch (UnauthorizedAccessException ex)
        {
            ShowStartupError(ex.Message);
            Shutdown();
        }
        catch (SecurityException ex)
        {
            ShowStartupError(ex.Message);
            Shutdown();
        }
        catch (InvalidOperationException ex)
        {
            ShowStartupError(ex.Message);
            Shutdown();
        }
        catch (System.Runtime.InteropServices.COMException ex)
        {
            ShowStartupError($"Could not create a Windows shortcut: {ex.Message}");
            Shutdown();
        }
        catch (Win32Exception ex)
        {
            ShowStartupError($"Windows could not start or register Shadow Antivirus: {ex.Message}");
            Shutdown();
        }
    }

    private static void ShowStartupError(string message) =>
        MessageBox.Show(
            message,
            "Shadow Antivirus",
            MessageBoxButton.OK,
            MessageBoxImage.Error);
}
