using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;

namespace ProcessSentinel;

public partial class MainWindow : Window
{
    private static readonly string RulesPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ShadowAntivirus",
        "rules.json");
    private static readonly string LegacyRulesPath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ProcessSentinel",
        "rules.json");

    private readonly ObservableCollection<ProcessRow> _processes = [];
    private readonly HashSet<string> _deniedPaths = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<string> _allowedPaths = new(StringComparer.OrdinalIgnoreCase);
    private readonly DispatcherTimer _refreshTimer = new() { Interval = TimeSpan.FromSeconds(2) };
    private readonly ICollectionView _processView;
    private bool _isRefreshing;
    private string? _backgroundPath;

    public MainWindow()
    {
        InitializeComponent();
        _processView = CollectionViewSource.GetDefaultView(_processes);
        _processView.Filter = MatchesSearch;
        ProcessesGrid.ItemsSource = _processView;
        LoadRules();

        _refreshTimer.Tick += RefreshTimer_OnTick;
        _refreshTimer.Start();
        Loaded += MainWindow_OnLoaded;
        Closed += (_, _) => _refreshTimer.Stop();
    }

    private void MainWindow_OnLoaded(object sender, RoutedEventArgs e)
    {
        RefreshProcesses();
    }

    private void RefreshTimer_OnTick(object? sender, EventArgs e) => RefreshProcesses();

    private void RefreshButton_OnClick(object sender, RoutedEventArgs e) => RefreshProcesses();

    private void ChangeBackgroundButton_OnClick(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Choose a background image or live wallpaper",
            Filter = "Backgrounds|*.jpg;*.jpeg;*.png;*.mp4;*.wmv|Images|*.jpg;*.jpeg;*.png|Live wallpapers (video)|*.mp4;*.wmv",
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog(this) != true)
        {
            return;
        }

        var previousBackground = _backgroundPath;
        _backgroundPath = dialog.FileName;
        ApplyBackground();
        if (!SaveRules())
        {
            _backgroundPath = previousBackground;
            ApplyBackground();
            return;
        }

        ActionStatusText.Text = "Background saved. Video wallpapers play muted and loop.";
    }

    private void ResetBackgroundButton_OnClick(object sender, RoutedEventArgs e)
    {
        var previousBackground = _backgroundPath;
        _backgroundPath = null;
        BackgroundVideo.Stop();
        BackgroundVideo.Source = null;
        BackgroundVideo.Visibility = Visibility.Collapsed;
        BackgroundImage.Source = null;
        BackgroundImage.Visibility = Visibility.Collapsed;
        if (!SaveRules())
        {
            _backgroundPath = previousBackground;
            ApplyBackground();
            return;
        }

        ActionStatusText.Text = "Background reset to the default.";
    }

    private void BackgroundVideo_OnMediaEnded(object sender, RoutedEventArgs e)
    {
        BackgroundVideo.Position = TimeSpan.Zero;
        BackgroundVideo.Play();
    }

    private void BackgroundVideo_OnMediaFailed(object sender, System.Windows.ExceptionRoutedEventArgs e)
    {
        ActionStatusText.Text = $"Could not play the selected live wallpaper: {e.ErrorException.Message}";
        BackgroundVideo.Stop();
        BackgroundVideo.Visibility = Visibility.Collapsed;
    }

    private void UninstallButton_OnClick(object sender, RoutedEventArgs e)
    {
        var executablePath = Environment.ProcessPath;
        if (string.IsNullOrWhiteSpace(executablePath))
        {
            ActionStatusText.Text = "Could not determine the installed executable path.";
            return;
        }

        try
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = executablePath,
                ArgumentList = { "--uninstall" },
                UseShellExecute = true
            });
            Close();
        }
        catch (Win32Exception ex)
        {
            ActionStatusText.Text = $"Could not start the uninstaller: {ex.Message}";
        }
    }

    private void SearchBox_OnTextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e) =>
        _processView.Refresh();

    private void ProcessesGrid_OnSelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) =>
        UpdateSelectedProcess();

    private void RefreshProcesses()
    {
        if (_isRefreshing)
        {
            return;
        }

        _isRefreshing = true;
        try
        {
            var rows = new List<ProcessRow>();
            var runningPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var process in Process.GetProcesses())
            {
                using (process)
                {
                    try
                    {
                        var path = process.MainModule?.FileName ?? string.Empty;
                        var normalizedPath = NormalizePath(path);
                        if (normalizedPath.Length > 0)
                        {
                            runningPaths.Add(normalizedPath);
                        }

                        var status = normalizedPath.Length == 0
                            ? "Path unavailable"
                            : _deniedPaths.Contains(normalizedPath)
                                ? "Denied by monitor"
                                : _allowedPaths.Contains(normalizedPath)
                                    ? "Allowed"
                                    : "Running";

                        if (normalizedPath.Length > 0 && _deniedPaths.Contains(normalizedPath))
                        {
                            StopDeniedProcess(process.Id, normalizedPath);
                        }

                        rows.Add(new ProcessRow(
                            process.Id,
                            process.ProcessName,
                            path,
                            status,
                            ProcessRiskEvaluator.Assess(process.ProcessName, path)));
                    }
                    catch (Win32Exception)
                    {
                        var name = SafeProcessName(process);
                        rows.Add(new ProcessRow(
                            process.Id,
                            name,
                            string.Empty,
                            "Path unavailable",
                            "Unknown — path unavailable"));
                    }
                    catch (InvalidOperationException)
                    {
                        // The process exited between enumeration and inspection.
                    }
                }
            }

            foreach (var path in _deniedPaths.Where(path => !runningPaths.Contains(path)))
            {
                rows.Add(new ProcessRow(
                    null,
                    Path.GetFileNameWithoutExtension(path),
                    path,
                    "Blocked (not running)",
                    "Blocked by your rule"));
            }

            var selected = ProcessesGrid.SelectedItem as ProcessRow;
            var selectedId = selected?.Id;
            var selectedPath = selected?.Path;
            _processes.Clear();
            foreach (var row in rows.OrderBy(row => row.Name, StringComparer.OrdinalIgnoreCase))
            {
                _processes.Add(row);
            }

            _processView.Refresh();
            if (selectedId is int id)
            {
                ProcessesGrid.SelectedItem = _processes.FirstOrDefault(row => row.Id == id);
            }
            else if (!string.IsNullOrEmpty(selectedPath))
            {
                ProcessesGrid.SelectedItem = _processes.FirstOrDefault(row =>
                    string.Equals(row.Path, selectedPath, StringComparison.OrdinalIgnoreCase));
            }

            ProcessCountText.Text =
                $"{rows.Count(row => row.Id.HasValue)} processes · {_deniedPaths.Count} blocked";
            UpdateSelectedProcess();
        }
        finally
        {
            _isRefreshing = false;
        }
    }

    private void StopDeniedProcess(int processId, string path)
    {
        try
        {
            using var process = Process.GetProcessById(processId);
            if (!IsProtectedProcess(process, path))
            {
                process.Kill(entireProcessTree: true);
                ActionStatusText.Text = $"Stopped denied process {process.ProcessName} (PID {processId}).";
            }
        }
        catch (ArgumentException)
        {
            // The process exited before it could be stopped.
        }
        catch (InvalidOperationException)
        {
            // The process exited before it could be stopped.
        }
        catch (Win32Exception ex)
        {
            ActionStatusText.Text = $"Could not stop PID {processId}: {ex.Message}";
        }
    }

    private void AllowButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (ProcessesGrid.SelectedItem is not ProcessRow selected || selected.Path.Length == 0)
        {
            return;
        }

        var path = NormalizePath(selected.Path);
        if (!_deniedPaths.Contains(path))
        {
            return;
        }

        _deniedPaths.Remove(path);
        var wasAllowed = _allowedPaths.Add(path);
        if (!SaveRules())
        {
            _deniedPaths.Add(path);
            if (!wasAllowed)
            {
                _allowedPaths.Remove(path);
            }

            return;
        }

        ActionStatusText.Text =
            $"Allowed {selected.Name}. The monitor will no longer stop it; start it manually if needed.";
        RefreshProcesses();
    }

    private void DenyButton_OnClick(object sender, RoutedEventArgs e)
    {
        if (ProcessesGrid.SelectedItem is not ProcessRow selected
            || selected.Id is not int processId
            || selected.Path.Length == 0)
        {
            return;
        }

        if (!File.Exists(selected.Path))
        {
            ActionStatusText.Text = "The executable path is no longer available.";
            return;
        }

        if (IsProtectedProcessPath(selected.Path))
        {
            ActionStatusText.Text = "For safety, Shadow Antivirus will not deny Windows system executables.";
            return;
        }

        var answer = MessageBox.Show(
            $"Deny {selected.Name}?\n\nShadow Antivirus will stop the running process and stop later instances shortly after they start, while this app is running. This is not a guaranteed launch block and does not change Windows security policy.\n\n{selected.Path}",
            "Confirm deny",
            MessageBoxButton.YesNo,
            MessageBoxImage.Warning);
        if (answer != MessageBoxResult.Yes)
        {
            return;
        }

        var path = NormalizePath(selected.Path);
        var wasAllowed = _allowedPaths.Remove(path);
        _deniedPaths.Add(path);
        if (!SaveRules())
        {
            _deniedPaths.Remove(path);
            if (wasAllowed)
            {
                _allowedPaths.Add(path);
            }

            return;
        }

        try
        {
            using var process = Process.GetProcessById(processId);
            process.Kill(entireProcessTree: true);
            ActionStatusText.Text = $"Denied {selected.Name} in this monitor and stopped PID {processId}.";
        }
        catch (ArgumentException)
        {
            ActionStatusText.Text = $"{selected.Name} exited. The monitor will stop later instances while it is open.";
        }
        catch (InvalidOperationException)
        {
            ActionStatusText.Text = $"{selected.Name} exited. The monitor will stop later instances while it is open.";
        }
        catch (Win32Exception ex)
        {
            ActionStatusText.Text =
                $"Added the monitor deny rule, but Windows did not allow stopping this process: {ex.Message}";
        }

        RefreshProcesses();
    }

    private void UpdateSelectedProcess()
    {
        if (ProcessesGrid.SelectedItem is not ProcessRow selected)
        {
            SelectedProcessText.Text = "Select a process to see its details.";
            SelectedPathText.Text = string.Empty;
            AllowButton.IsEnabled = false;
            DenyButton.IsEnabled = false;
            return;
        }

        SelectedProcessText.Text = selected.Id is int id
            ? $"{selected.Name}  •  PID {id}  •  {selected.Status}"
            : $"{selected.Name}  •  {selected.Status}";
        SelectedPathText.Text = selected.Path.Length > 0 ? selected.Path : "Executable path is unavailable.";
        AllowButton.IsEnabled = selected.Path.Length > 0
            && _deniedPaths.Contains(NormalizePath(selected.Path));
        DenyButton.IsEnabled = selected.Id.HasValue
            && selected.Path.Length > 0
            && !IsProtectedProcessPath(selected.Path);
    }

    private bool MatchesSearch(object item)
    {
        if (item is not ProcessRow row)
        {
            return false;
        }

        var query = SearchBox?.Text.Trim();
        return string.IsNullOrEmpty(query)
            || row.Name.Contains(query, StringComparison.OrdinalIgnoreCase)
            || row.Id?.ToString().Contains(query, StringComparison.OrdinalIgnoreCase) == true
            || row.Status.Contains(query, StringComparison.OrdinalIgnoreCase)
            || row.Assessment.Contains(query, StringComparison.OrdinalIgnoreCase)
            || row.Path.Contains(query, StringComparison.OrdinalIgnoreCase);
    }

    private void LoadRules()
    {
        try
        {
            var rulesPath = File.Exists(RulesPath) ? RulesPath : LegacyRulesPath;
            if (!File.Exists(rulesPath))
            {
                return;
            }

            var data = JsonSerializer.Deserialize<MonitorRules>(File.ReadAllText(rulesPath));
            if (data is null)
            {
                return;
            }

            foreach (var path in data.DeniedPaths)
            {
                _deniedPaths.Add(NormalizePath(path));
            }

            foreach (var path in data.AllowedPaths)
            {
                _allowedPaths.Add(NormalizePath(path));
            }

            _backgroundPath = data.BackgroundPath;
            ApplyBackground();
            if (rulesPath == LegacyRulesPath)
            {
                SaveRules();
            }
        }
        catch (IOException ex)
        {
            ActionStatusText.Text = $"Could not read saved monitor rules: {ex.Message}";
        }
        catch (JsonException ex)
        {
            ActionStatusText.Text = $"Saved monitor rules are invalid: {ex.Message}";
        }
    }

    private bool SaveRules()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(RulesPath)!);
            var data = new MonitorRules(_deniedPaths.ToArray(), _allowedPaths.ToArray(), _backgroundPath);
            File.WriteAllText(RulesPath, JsonSerializer.Serialize(data, new JsonSerializerOptions
            {
                WriteIndented = true
            }));
            return true;
        }
        catch (IOException ex)
        {
            ActionStatusText.Text = $"Could not save monitor rules: {ex.Message}";
            return false;
        }
        catch (UnauthorizedAccessException ex)
        {
            ActionStatusText.Text = $"Could not save monitor rules: {ex.Message}";
            return false;
        }
    }

    private void ApplyBackground()
    {
        if (string.IsNullOrWhiteSpace(_backgroundPath))
        {
            return;
        }

        if (!File.Exists(_backgroundPath))
        {
            ActionStatusText.Text = $"Saved background file not found: {_backgroundPath}";
            return;
        }

        var extension = Path.GetExtension(_backgroundPath);
        try
        {
            if (extension.Equals(".mp4", StringComparison.OrdinalIgnoreCase)
                || extension.Equals(".wmv", StringComparison.OrdinalIgnoreCase))
            {
                BackgroundImage.Source = null;
                BackgroundImage.Visibility = Visibility.Collapsed;
                BackgroundVideo.Stop();
                BackgroundVideo.Source = new Uri(_backgroundPath, UriKind.Absolute);
                BackgroundVideo.Visibility = Visibility.Visible;
                BackgroundVideo.Play();
                return;
            }

            BackgroundVideo.Stop();
            BackgroundVideo.Source = null;
            BackgroundVideo.Visibility = Visibility.Collapsed;
            var image = new BitmapImage();
            image.BeginInit();
            image.UriSource = new Uri(_backgroundPath, UriKind.Absolute);
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.EndInit();
            image.Freeze();
            BackgroundImage.Source = image;
            BackgroundImage.Visibility = Visibility.Visible;
        }
        catch (IOException ex)
        {
            ActionStatusText.Text = $"Could not load the selected background: {ex.Message}";
        }
        catch (UnauthorizedAccessException ex)
        {
            ActionStatusText.Text = $"Could not load the selected background: {ex.Message}";
        }
        catch (FormatException ex)
        {
            ActionStatusText.Text = $"Could not load the selected background: {ex.Message}";
        }
        catch (ArgumentException ex)
        {
            ActionStatusText.Text = $"Could not load the selected background: {ex.Message}";
        }
        catch (NotSupportedException ex)
        {
            ActionStatusText.Text = $"Could not load the selected background: {ex.Message}";
        }
    }

    private sealed record MonitorRules(string[] DeniedPaths, string[] AllowedPaths, string? BackgroundPath);

    private static bool IsProtectedProcess(Process process, string path) =>
        process.Id <= 4 || IsProtectedProcessPath(path);

    private static bool IsProtectedProcessPath(string path)
    {
        var windows = NormalizePath(Environment.GetFolderPath(Environment.SpecialFolder.Windows));
        var normalized = NormalizePath(path);
        return normalized.Length > 0
            && (normalized.Equals(windows, StringComparison.OrdinalIgnoreCase)
                || normalized.StartsWith(windows + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase));
    }

    private static string NormalizePath(string path)
    {
        try
        {
            return Path.GetFullPath(path);
        }
        catch (ArgumentException)
        {
            return string.Empty;
        }
        catch (NotSupportedException)
        {
            return string.Empty;
        }
        catch (PathTooLongException)
        {
            return string.Empty;
        }
    }

    private static string SafeProcessName(Process process)
    {
        try
        {
            return process.ProcessName;
        }
        catch (InvalidOperationException)
        {
            return "Unknown";
        }
    }

}
