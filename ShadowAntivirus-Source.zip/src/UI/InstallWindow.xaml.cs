using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace ProcessSentinel;

public partial class InstallWindow : Window
{
    public string InstallDirectory { get; private set; } = string.Empty;

    public InstallWindow()
    {
        InitializeComponent();
        InstallDirectoryBox.Text = InstallationManager.GetSuggestedInstallDirectory();
    }

    private void BrowseButton_OnClick(object sender, RoutedEventArgs e)
    {
        var currentDirectory = InstallDirectoryBox.Text.Trim();
        var initialDirectory = Directory.Exists(currentDirectory)
            ? currentDirectory
            : Path.GetDirectoryName(currentDirectory);
        var dialog = new OpenFolderDialog
        {
            Title = "Choose the Shadow Antivirus install folder",
            InitialDirectory = Directory.Exists(initialDirectory)
                ? initialDirectory
                : Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            Multiselect = false
        };

        if (dialog.ShowDialog(this) == true)
        {
            InstallDirectoryBox.Text = dialog.FolderName;
        }
    }

    private void InstallButton_OnClick(object sender, RoutedEventArgs e)
    {
        var selected = InstallDirectoryBox.Text.Trim();
        if (selected.Length == 0)
        {
            MessageBox.Show(
                this,
                "Enter or choose an install folder.",
                "Set up Shadow Antivirus",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
            return;
        }

        try
        {
            InstallDirectory = Path.GetFullPath(selected);
        }
        catch (ArgumentException ex)
        {
            ShowInvalidFolder(ex.Message);
            return;
        }
        catch (NotSupportedException ex)
        {
            ShowInvalidFolder(ex.Message);
            return;
        }
        catch (PathTooLongException ex)
        {
            ShowInvalidFolder(ex.Message);
            return;
        }

        DialogResult = true;
    }

    private void CancelButton_OnClick(object sender, RoutedEventArgs e) => DialogResult = false;

    private void ShowInvalidFolder(string message) =>
        MessageBox.Show(
            this,
            $"That install folder is not valid: {message}",
            "Set up Shadow Antivirus",
            MessageBoxButton.OK,
            MessageBoxImage.Warning);
}
