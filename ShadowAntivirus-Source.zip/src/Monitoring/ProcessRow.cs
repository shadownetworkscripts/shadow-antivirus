namespace ProcessSentinel;

public sealed record ProcessRow(int? Id, string Name, string Path, string Status, string Assessment);
