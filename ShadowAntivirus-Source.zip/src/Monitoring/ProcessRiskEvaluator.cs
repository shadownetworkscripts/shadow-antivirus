using System.IO;

namespace ProcessSentinel;

internal static class ProcessRiskEvaluator
{
    private static readonly HashSet<string> SensitiveWindowsNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "csrss.exe",
        "lsass.exe",
        "services.exe",
        "smss.exe",
        "spoolsv.exe",
        "svchost.exe",
        "wininit.exe",
        "winlogon.exe"
    };

    public static string Assess(string processName, string executablePath)
    {
        if (string.IsNullOrWhiteSpace(executablePath) || !File.Exists(executablePath))
        {
            return "Unknown — path unavailable";
        }

        var fullPath = Path.GetFullPath(executablePath);
        var fileName = Path.GetFileName(fullPath);
        var windowsDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var systemDirectories = new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.System),
            Path.Combine(windowsDirectory, "SysWOW64")
        };

        if (SensitiveWindowsNames.Contains(fileName)
            && !systemDirectories.Any(directory => IsWithin(fullPath, directory)))
        {
            return "High risk — Windows-name lookalike";
        }

        var userProfile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        var reviewDirectories = new[]
        {
            Path.GetTempPath(),
            Path.Combine(userProfile, "Downloads"),
            Environment.GetFolderPath(Environment.SpecialFolder.Startup)
        };
        var suspiciousDirectory = reviewDirectories.FirstOrDefault(directory => IsWithin(fullPath, directory));
        if (suspiciousDirectory is not null)
        {
            return "Review — writable launch location";
        }

        return "No obvious risk flags";
    }

    private static bool IsWithin(string filePath, string directory)
    {
        if (string.IsNullOrWhiteSpace(directory))
        {
            return false;
        }

        var normalizedDirectory = Path.GetFullPath(directory)
            .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar)
            + Path.DirectorySeparatorChar;
        var normalizedPath = Path.GetFullPath(filePath);
        return normalizedPath.StartsWith(normalizedDirectory, StringComparison.OrdinalIgnoreCase);
    }
}
